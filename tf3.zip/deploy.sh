#!/usr/bin/env bash
set -euo pipefail

command -v terraform >/dev/null 2>&1 || { echo "[!] Terraform no está instalado en PATH"; exit 1; }

echo "=== Despliegue OpenVPN VM en Azure (Terraform) ==="
read -rp "Nombre del Resource Group a crear/usar (ej: ovpn-prod-rg): " RG_NAME
while [[ -z "${RG_NAME}" ]]; do
  read -rp "El nombre no puede estar vacío. Intenta de nuevo: " RG_NAME
done

read -rp "Ubicación/Región Azure (default: eastus): " LOCATION
LOCATION=${LOCATION:-eastus}

read -rp "Prefijo para nombres de recursos (default: ovpn): " PREFIX
PREFIX=${PREFIX:-ovpn}

echo ""
echo "== SSH Key existente en Azure =="
read -rp "Nombre del recurso azurerm_ssh_public_key (ej: my-sshkey): " SSH_KEY_NAME
while [[ -z "${SSH_KEY_NAME}" ]]; do
  read -rp "El nombre no puede estar vacío. Intenta de nuevo: " SSH_KEY_NAME
done

read -rp "Resource Group donde está la SSH key (ej: shared-sec-rg): " SSH_KEY_RG
while [[ -z "${SSH_KEY_RG}" ]]; do
  read -rp "El RG no puede estar vacío. Intenta de nuevo: " SSH_KEY_RG
done

# Opcionales (puedes dejarlos por defecto)
read -rp "Usuario admin de la VM (default: azureuser): " ADMIN_USER
ADMIN_USER=${ADMIN_USER:-azureuser}

read -rp "VM size (default: Standard_B1ms): " VM_SIZE
VM_SIZE=${VM_SIZE:-Standard_B1ms}

read -rp "CIDR de la VNet (default: 192.168.252.0/24): " VNET_CIDR
VNET_CIDR=${VNET_CIDR:-192.168.252.0/24}

read -rp "CIDR de la Subnet (default: 192.168.252.0/26): " SUBNET_CIDR
SUBNET_CIDR=${SUBNET_CIDR:-192.168.252.0/26}

read -rp "URL del instalador OpenVPN (default: repo Watskip): " OVPN_URL
OVPN_URL=${OVPN_URL:-https://raw.githubusercontent.com/Watskip/openvpn-install/refs/heads/master/openvpn-install.sh}

cat > terraform.tfvars <<EOF
rg_name             = "${RG_NAME}"
location            = "${LOCATION}"
prefix              = "${PREFIX}"

vnet_cidr           = "${VNET_CIDR}"
subnet_cidr         = "${SUBNET_CIDR}"

vm_size             = "${VM_SIZE}"
admin_username      = "${ADMIN_USER}"

openvpn_install_url = "${OVPN_URL}"

ssh_key_name        = "${SSH_KEY_NAME}"
ssh_key_rg          = "${SSH_KEY_RG}"
EOF

echo ""
echo "[i] Archivo terraform.tfvars generado:"
cat terraform.tfvars

terraform init
terraform apply -auto-approve

echo "
✅ Despliegue completado."
