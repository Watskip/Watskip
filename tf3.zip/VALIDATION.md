# Validación de la configuración Terraform

## Requisitos
- Terraform >= 1.5
- (Opcional) TFLint

## Validación local
```bash
chmod +x validate.sh
./validate.sh
```

## Validación en CI (GitHub Actions)
Ejecuta los mismos pasos de validación en tu CI. Ejemplo de jobs:
- `terraform fmt -check -recursive`
- `terraform init -backend=false`
- `terraform validate`
- `tflint` (si está disponible)
