#!/usr/bin/env bash
set -euo pipefail
echo "[1/4] terraform fmt -check -recursive"
terraform fmt -check -recursive

echo "[2/4] terraform init -backend=false"
terraform init -backend=false > /dev/null

echo "[3/4] terraform validate"
terraform validate

if command -v tflint >/dev/null 2>&1; then
  echo "[4/4] tflint (opcional)"
  tflint --no-color
else
  echo "[4/4] tflint (omitido; no instalado)"
fi

echo "✅ Validación completada con éxito."
